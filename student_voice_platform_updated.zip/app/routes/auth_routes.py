
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash
from app.helpers.auth import authenticate_user
from app.models import db, Student, Staff, Admin

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form.get('role')
        identifier = request.form.get('identifier')
        password = request.form.get('password')
        user = authenticate_user(role, identifier, password)
        if user:
            session.clear()
            session['user_id'] = user.id
            session['role'] = role
            flash('Login successful','success')
            return redirect(url_for(f'{role}.dashboard'))
        flash('Invalid credentials','danger')
    return render_template('auth/login.html')
