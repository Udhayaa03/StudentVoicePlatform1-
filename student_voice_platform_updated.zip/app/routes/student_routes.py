
from flask import Blueprint, render_template, request, redirect, url_for, session, g, flash
from werkzeug.security import generate_password_hash
from app.models import db, Feedback, Category, Department
from app.helpers.stats import get_feedback_stats
from app.helpers.email import send_feedback_email
from app.helpers.audit import log_action

student_bp = Blueprint('student', __name__, url_prefix='/student')

@student_bp.before_request
def load_student():
    g.student_id = session.get('user_id')

@student_bp.route('/dashboard')
def dashboard():
    if not g.student_id:
        return redirect(url_for('auth.login'))
    stats = get_feedback_stats(user_type='student', user_id=g.student_id)
    return render_template('student/dashboard.html', stats=stats)

@student_bp.route('/submit-feedback', methods=['GET','POST'])
def submit_feedback():
    if not g.student_id:
        return redirect(url_for('auth.login'))
    if request.method == 'POST':
        subject = request.form['subject']
        description = request.form['description']
        category_id = request.form['category']
        department_id = request.form.get('department') or None
        anonymous = bool(request.form.get('anonymous'))
        fb = Feedback(
            subject=subject,
            description=description,
            category_id=category_id,
            department_id=department_id,
            submitted_by=g.student_id,
            anonymous=anonymous
        )
        db.session.add(fb)
        db.session.commit()
        log_action(fb.id, "Feedback submitted", g.student_id, 'student')
        flash('Feedback submitted','success')
        return redirect(url_for('student.dashboard'))
    categories = Category.query.filter_by(parent_id=None).all()
    departments= Department.query.all()
    return render_template('student/submit_feedback.html',
                           categories=categories,
                           departments=departments)
