
from flask import Blueprint, render_template, session, g, redirect, url_for, request, flash
from app.models import db, Staff, Feedback, Response, Category
from app.helpers.stats import get_feedback_stats
from app.helpers.audit import log_action

staff_bp = Blueprint('staff', __name__, url_prefix='/staff')

@staff_bp.before_request
def load_staff():
    g.staff_id = session.get('user_id')
    if g.staff_id:
        g.staff = Staff.query.get(g.staff_id)
        g.department_id = g.staff.department_id

@staff_bp.route('/dashboard')
def dashboard():
    if not g.staff_id:
        return redirect(url_for('auth.login'))
    stats = get_feedback_stats(user_type='staff', department_id=g.department_id)
    feedback_items = Feedback.query.filter_by(department_id=g.department_id).order_by(Feedback.created_at.desc()).all()
    categories = Category.query.filter_by(parent_id=None).all()
    return render_template('staff/dashboard.html', stats=stats, feedback_items=feedback_items, categories=categories)

@staff_bp.route('/feedback/<int:fb_id>', methods=['GET','POST'])
def feedback_detail(fb_id):
    if not g.staff_id:
        return redirect(url_for('auth.login'))
    fb = Feedback.query.get_or_404(fb_id)
    if fb.department_id != g.department_id:
        flash('Not allowed','danger')
        return redirect(url_for('staff.dashboard'))
    if request.method == 'POST':
        new_status = request.form.get('status')
        assign_to  = request.form.get('assign_to') or None
        response_body = request.form.get('response')
        if new_status and new_status != fb.status:
            fb.status = new_status
            log_action(fb.id, f"Status changed to {new_status}", g.staff_id, 'staff')
        if assign_to and assign_to != fb.assigned_to:
            fb.assigned_to = assign_to
            log_action(fb.id, "Reassigned feedback", g.staff_id, 'staff')
        if response_body:
            db.session.add(Response(feedback_id=fb.id, responder_id=g.staff_id,
                                    responder_role='staff', body=response_body))
            log_action(fb.id, "Added response", g.staff_id, 'staff')
        db.session.commit()
        flash('Changes saved','success')
        return redirect(url_for('staff.feedback_detail', fb_id=fb_id))
    staff_list = Staff.query.filter_by(department_id=g.department_id).all()
    return render_template('staff/feedback_detail.html', fb=fb, staff_list=staff_list)
