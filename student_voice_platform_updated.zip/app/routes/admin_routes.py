
from flask import Blueprint, render_template, redirect, url_for, session, g, request, flash, send_file
import pandas as pd
from io import StringIO, BytesIO
from datetime import datetime
from werkzeug.security import generate_password_hash
from app.models import db, Feedback, Staff, Department, Response, Category, Student
from app.helpers.stats import get_feedback_stats
from app.helpers.audit import log_action

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.before_request
def load_admin():
    g.admin_id = session.get('user_id')

@admin_bp.route('/dashboard')
def dashboard():
    stats = get_feedback_stats(user_type='admin')
    feedback_items = Feedback.query.order_by(Feedback.created_at.desc()).limit(20).all()
    return render_template('admin/dashboard.html', stats=stats, feedback_items=feedback_items)

@admin_bp.route('/feedback/<int:fb_id>', methods=['GET','POST'])
def feedback_detail(fb_id):
    fb = Feedback.query.get_or_404(fb_id)
    departments = Department.query.all()
    staff_list = Staff.query.all()
    if request.method == 'POST':
        new_status = request.form.get('status')
        assign_to  = request.form.get('assign_to') or None
        response_text = request.form.get('response')
        if new_status and new_status != fb.status:
            fb.status = new_status
            log_action(fb.id, f"Status changed to {new_status}", g.admin_id, 'admin')
        if assign_to and assign_to != fb.assigned_to:
            fb.assigned_to = assign_to
            log_action(fb.id, "Assigned feedback", g.admin_id, 'admin')
        if response_text:
            db.session.add(Response(feedback_id=fb.id, responder_id=g.admin_id,
                                    responder_role='admin', body=response_text))
            log_action(fb.id, "Added response", g.admin_id, 'admin')
        db.session.commit()
        flash('Changes saved','success')
        return redirect(url_for('admin.feedback_detail', fb_id=fb_id))
    return render_template('admin/feedback_detail.html', fb=fb, departments=departments, staff_list=staff_list)

@admin_bp.route('/export-feedback')
def export_feedback():
    fmt = request.args.get('format','csv')
    query = Feedback.query
    status = request.args.get('status')
    if status:
        query = query.filter_by(status=status)
    records = query.all()
    data = []
    for f in records:
        data.append({
            'ID': f.id,
            'Subject': f.subject,
            'Category': f.category.name if f.category else '',
            'Department': f.department.name if f.department else '',
            'Submitted By': ('Anonymous' if f.anonymous else f.student.name) if f.student else '',
            'Date': f.created_at.strftime('%Y-%m-%d'),
            'Status': f.status
        })
    df = pd.DataFrame(data)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M')
    if fmt == 'excel':
        buf = BytesIO()
        df.to_excel(buf, index=False)
        buf.seek(0)
        return send_file(buf, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                         download_name=f'feedback_{timestamp}.xlsx', as_attachment=True)
    else:
        csv_str = df.to_csv(index=False)
        return send_file(BytesIO(csv_str.encode()), mimetype='text/csv',
                         download_name=f'feedback_{timestamp}.csv', as_attachment=True)
