
from app.models import AuditLog, db
from datetime import datetime

def log_action(feedback_id, action, actor_id, actor_role):
    db.session.add(AuditLog(
        feedback_id=feedback_id,
        action=action,
        actor_id=actor_id,
        actor_role=actor_role,
        timestamp=datetime.utcnow()
    ))
    db.session.commit()
