
from flask_mailman import EmailMessage

def send_feedback_email(to_email, subject, body):
    msg = EmailMessage(subject=subject, body=body, to=[to_email])
    msg.send()
