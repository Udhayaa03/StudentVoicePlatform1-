
from app.models import Feedback
from sqlalchemy import func

def get_feedback_stats(user_type=None, user_id=None, department_id=None):
    query = Feedback.query
    if user_type == 'student':
        query = query.filter(Feedback.submitted_by == user_id)
    elif user_type == 'staff':
        query = query.filter(Feedback.department_id == department_id)

    return {
        'total': query.count(),
        'submitted': query.filter(Feedback.status=='submitted').count(),
        'under_review': query.filter(Feedback.status=='under_review').count(),
        'action_taken': query.filter(Feedback.status=='action_taken').count(),
        'closed': query.filter(Feedback.status=='closed').count(),
    }
