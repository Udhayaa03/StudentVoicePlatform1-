
from werkzeug.security import check_password_hash
from app.models import db, Student, Staff, Admin

def authenticate_user(role: str, identifier: str, password: str):
    model_map = {
        'student': Student,
        'staff':   Staff,
        'admin':   Admin,
    }
    column_map = {
        'student': Student.registration_no,
        'staff':   Staff.employee_id,
        'admin':   Admin.admin_id,
    }
    model_cls = model_map.get(role)
    column    = column_map.get(role)
    if not model_cls:
        return None
    user = db.session.query(model_cls).filter(column == identifier).first()
    if user and check_password_hash(user.password_hash, password):
        return user
    return None
