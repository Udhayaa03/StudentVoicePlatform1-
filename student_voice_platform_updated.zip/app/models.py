
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Department(db.Model):
    __tablename__ = 'departments'
    id   = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)

class Category(db.Model):
    __tablename__ = 'categories'
    id        = db.Column(db.Integer, primary_key=True)
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    name      = db.Column(db.String(120), nullable=False)
    parent    = db.relationship('Category', remote_side=[id], backref='children')

class Student(db.Model):
    __tablename__ = 'students'
    id              = db.Column(db.Integer, primary_key=True)
    registration_no = db.Column(db.String(30), unique=True, nullable=False)
    name            = db.Column(db.String(120), nullable=False)
    email           = db.Column(db.String(120))
    password_hash   = db.Column(db.String(255), nullable=False)

class Staff(db.Model):
    __tablename__ = 'staff'
    id            = db.Column(db.Integer, primary_key=True)
    employee_id   = db.Column(db.String(30), unique=True, nullable=False)
    name          = db.Column(db.String(120), nullable=False)
    email         = db.Column(db.String(120))
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'))
    password_hash = db.Column(db.String(255), nullable=False)
    department    = db.relationship('Department')

class Admin(db.Model):
    __tablename__ = 'admins'
    id           = db.Column(db.Integer, primary_key=True)
    admin_id     = db.Column(db.String(30), unique=True, nullable=False)
    name         = db.Column(db.String(120), nullable=False)
    email        = db.Column(db.String(120))
    password_hash= db.Column(db.String(255), nullable=False)

class Feedback(db.Model):
    __tablename__ = 'feedback'
    id            = db.Column(db.Integer, primary_key=True)
    subject       = db.Column(db.String(200), nullable=False)
    description   = db.Column(db.Text, nullable=False)
    anonymous     = db.Column(db.Boolean, default=False)
    category_id   = db.Column(db.Integer, db.ForeignKey('categories.id'))
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'))
    submitted_by  = db.Column(db.Integer, db.ForeignKey('students.id'))
    assigned_to   = db.Column(db.Integer, db.ForeignKey('staff.id'))
    status        = db.Column(db.Enum('submitted', 'under_review', 'action_taken', 'closed',
                                      name='feedback_status'), default='submitted', nullable=False)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at    = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    student    = db.relationship('Student', backref='feedback_items')
    staff      = db.relationship('Staff', foreign_keys=[assigned_to], backref='assigned_feedback')
    category   = db.relationship('Category')
    department = db.relationship('Department')

class Response(db.Model):
    __tablename__ = 'responses'
    id            = db.Column(db.Integer, primary_key=True)
    feedback_id   = db.Column(db.Integer, db.ForeignKey('feedback.id'))
    responder_id  = db.Column(db.Integer)
    responder_role= db.Column(db.Enum('staff','admin'))
    body          = db.Column(db.Text, nullable=False)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    feedback      = db.relationship('Feedback', backref='responses')

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id          = db.Column(db.Integer, primary_key=True)
    feedback_id = db.Column(db.Integer, db.ForeignKey('feedback.id'), nullable=False)
    action      = db.Column(db.String(255), nullable=False)
    actor_id    = db.Column(db.Integer)
    actor_role  = db.Column(db.String(50), nullable=False)
    timestamp   = db.Column(db.DateTime, default=datetime.utcnow)
    feedback    = db.relationship('Feedback', backref='audit_logs')
