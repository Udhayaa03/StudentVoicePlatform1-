
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_mailman import Mail
from .models import db
from .routes.auth_routes import auth_bp
from .routes.student_routes import student_bp
from .routes.staff_routes import staff_bp
from .routes.admin_routes import admin_bp

mail = Mail()

def create_app():
    from config import Config
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)
    mail.init_app(app)

    # register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(staff_bp)
    app.register_blueprint(admin_bp)

    return app
