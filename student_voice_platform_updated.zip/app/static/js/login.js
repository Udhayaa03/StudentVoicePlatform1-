
document.addEventListener('DOMContentLoaded', () => {
  const roleSel = document.getElementById('roleSelect');
  const studentBlock = document.getElementById('studentFields');
  const staffBlock = document.getElementById('staffFields');
  const adminBlock = document.getElementById('adminFields');
  const toggle = () => {
    const role = roleSel.value;
    const show = (block, enable) => {
      block.classList.toggle('d-none', !enable);
      block.querySelectorAll('input').forEach(i => i.disabled = !enable);
    };
    show(studentBlock, role==='student');
    show(staffBlock, role==='staff');
    show(adminBlock, role==='admin');
  };
  roleSel.addEventListener('change', toggle);
  toggle();
});
