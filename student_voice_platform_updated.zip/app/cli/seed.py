
import click, random
from faker import Faker
from app.models import db, Category, Department, Staff
from werkzeug.security import generate_password_hash

fake = Faker()

CATEGORY_TREE = {
    "Academics": ["Curriculum & Subjects","Teaching & Learning Methods"],
    "Infrastructure & Facilities": ["Classrooms & Learning Spaces","Library & Study Areas"],
    "Student Life & Well-being": ["Clubs & Extracurricular Activities"],
    "Administration & Policies": ["School Rules & Discipline"],
    "General Suggestions": ["New Ideas for the School"]
}

DEPARTMENTS = ["English","History","Physics","Chemistry","Computer Science"]

STAFF_NAMES = ["Dr. Lakshmi Devi","Dr. Karthik Kumar","Prof. Meena Kumari","Prof. Suresh Rajan"]

@click.command('seed-data')
def seed_data():
    click.echo("Seeding data...")
    for pname, children in CATEGORY_TREE.items():
        parent = Category(name=pname)
        db.session.add(parent); db.session.flush()
        for child in children:
            db.session.add(Category(name=child, parent_id=parent.id))
    for name in DEPARTMENTS:
        db.session.add(Department(name=name))
    db.session.commit()
    depts = Department.query.all()
    for full_name in STAFF_NAMES:
        db.session.add(Staff(
            employee_id=fake.unique.bothify("EMP###"),
            name=full_name,
            department_id=random.choice(depts).id,
            password_hash=generate_password_hash("password")
        ))
    db.session.commit()
    click.echo("Done.")
